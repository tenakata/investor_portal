import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Link } from 'react-router-dom';
import ApiRequest from './ApiRequest';

const Navbar = () => {
  const { getuserId } = ApiRequest();
  const [userName, setUserName] = useState(null);
  const [userRole, setUserRole] = useState(null);
  const [small, setSmall] = useState(window.innerWidth <= 768);
  const [id, setId] = useState(null);
  useEffect(() => {
    setId(getuserId);
  }, []);
  useEffect(() => {
    if (id === null) return;

    axios.get(`http://localhost:8000/api/user/${id}`)
      .then(response => {
        setUserRole(response.data.role);
        setUserName(response.data.username);
      })
      .catch(error => {
        console.error('Error fetching user data:', error);
        // Handle error appropriately
      });
  }, [id]);

  // Handle window resize
  useEffect(() => {
    const handleResize = () => {
      setSmall(window.innerWidth <= 768);
    };

    window.addEventListener('resize', handleResize);
    return () => {
      window.removeEventListener('resize', handleResize);
    };
  }, []);

  return (
    <div>
      {small ? (
        <div className='flex items-center justify-center mb-3'>
          <span className="search">
            <div className="search-container">
              <i className="bx bx-search search-icon"></i>
              <input type="text" placeholder="Search..." className="search-input" />
            </div>
          </span>
          <span className='profile-sm'>
            <i className='bx bx-user text-2xl absolute top-6 right-4'></i>
          </span>
        </div>
      ) : (
        <div className="flex justify-between items-center px-4 w-full mb-5">
          <span className="text-2xl font-bold">Dashboard</span>

          <span className="search">
            <div className="search-container">
              <i className="bx bx-search search-icon"></i>
              <input type="text" placeholder="Search..." className="search-input" />
            </div>
          </span>

          <span className="flex gap-2">
            <span className="text-3xl mt-1 flex gap-5 items-center">
              <div className='w-8 h-lineheight bg-black opacity-70'></div>
              <i className="bx bx-bell"></i>
            </span>
            <span className="flex flex-row items-center">
              <div>
                <h1>{userName || "Loading..."}</h1>
                <h2 className="text-xs">{userRole || "Loading..."}</h2>
              </div>
              <div className="w-7 h-7 rounded-lg bg-gray-500 ml-2 profile"></div>
              <div className='menu bg-white p-4 absolute top-14 right-8'>
                <h1>Settings</h1>
                <h1>Edit Profile</h1>
                <Link to={'/'}>Log Out</Link>
              </div>
            </span>
          </span>
        </div>
      )}
    </div>
  );
};

export default Navbar;
