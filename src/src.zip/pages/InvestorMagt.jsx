import React, { useState, useEffect } from 'react';
import axios from 'axios';
import MgtNav from '../components/MgtNav';
import SidenavInves from '../components/SidenavInves';
import ApiRequest from '../components/ApiRequest';

const InvestorMgt = () => {
    const [users, setUsers] = useState([]);
    const {userId}=ApiRequest();
    useEffect(() => {
        const getUsers = async () => {
            try {
                const response = await axios.get(`http://localhost:8000/api/get_investor/${userId}`);
                setUsers(response.data);
            } catch (error) {
                console.error("Error fetching users:", error);
            }
        };

        getUsers();
    }, []);
    return (
        <div className='flex bg-buttonBlue min-w-screen'>
            <span className='lg:w-sidenavW w-0'>
                <SidenavInves />
            </span>
            <span className='flex flex-col bg-dashbg lg:rounded-l-2xl lg:w-contentW p-7 w-full mb-5'>
                <MgtNav />
                <div className='flex justify-between mb-5 pr-5'>
                    <span className='flex gap-2'>
                        <button className='bg-white border border-gray-500 px-5 py-2 rounded-lg flex items-center gap-2'>
                            Date range <i className='bx bx-calendar-alt'></i>
                        </button>
                        <button className='bg-white border border-gray-500 px-5 py-2 rounded-lg flex items-center gap-2'>
                            Export data <i className='bx bx-upload'></i>
                        </button>
                    </span>
                </div>
                <div className='pr-5'>
                    <table className='bg-white rounded-xl w-full'>
                        <thead>
                            <tr>
                                <th className='t-h'>Investor ID</th>
                                <th className='t-h'>Investor name</th>
                                <th className='t-h'>Email address</th>
                                <th className='t-h'>Phone Number</th>
                                <th className='t-h'>Type</th>
                                <th className='t-h'>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            {users.map((user, index) => (
                                <tr key={user.id}>
                                    <td className='t-d'>{index + 1}</td>
                                    <td className='t-d'>{user.fullName}</td>
                                    <td className='t-d'>{user.mailingAddress}</td>
                                    <td className='t-d'>{user.phoneNumber}</td>
                                    <td className='t-d'>{user.role == 2 ? 'Investor' : 'Admin'}</td>
                                    <td className='t-d'>
                                        {user.status == 1 ? 'Active' : 'Inactive'}
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            </span>
        </div>
    );
};

export default InvestorMgt;
